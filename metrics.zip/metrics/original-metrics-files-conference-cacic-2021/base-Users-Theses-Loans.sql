create table "User" (
"userID" int unsigned not null primary key,
"name" varchar(20) not null,
"email" varchar(20),
"type" varchar(1),
);

insert into "User"("userID", "name", "email", "type") values (1, 'Juan', 'juan@nosite.com', 'S');
insert into "User"("userID", "name", "email", "type") values (2, 'Pedro', 'juan@nosite.com', 'T');

create table "Thesis" (
"id" int unsigned not null primary key,
"author" varchar(20),
"title" varchar(60),
"pubDate" date,
"type" varchar(1),
"institution" varchar(50),
"supervisor" varchar(50)
);

insert into "Thesis"("id", "author", "title", "pubDate", "type", "institution", "supervisor")
      values (1, 'Marie Curie', 'Recherches sur les substances radioactives', '1903-01-01', 'D', 'Faculte des Sciences de Paris', 'Gabriel Lippmann');
insert into "Thesis"("id", "author", "title", "pubDate", "type", "institution", "supervisor")
      values (2, 'Claude Shannon', 'A symbolic analysis of relay and switching circuits', '1937-01-01', 'M', 'Massachusetts Institute of Technology', 'Vannevar Bush');

	  
	  
create table "Loan" (
   "userID" int unsigned not null,
   "id" int not null,
   "date" date,
   "timeDays" int,
   primary key ("userID", "id"),
   foreign key ("userID") references "User" ("userID") on delete restrict on update cascade,
   foreign key ("id") references "Thesis" ("id") on delete restrict on update cascade
);

insert into "Loan" ("userID", "id", "date", "timeDays" ) values (1, 1, '2020-09-01', 40);

